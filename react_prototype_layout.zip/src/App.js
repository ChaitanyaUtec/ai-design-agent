import React, { useState } from 'react';
import './styles.css';

function App() {
  const [prompt, setPrompt] = useState('');
  const [imageUrl, setImageUrl] = useState('');

  const handleGenerate = () => {
    // Placeholder for GenAI integration
    setImageUrl('https://via.placeholder.com/600x400?text=Generated+Design');
  };

  return (
    <div className="container">
      <h2>AI Design Agent</h2>
      <input
        type="text"
        placeholder="Enter your design prompt..."
        value={prompt}
        onChange={(e) => setPrompt(e.target.value)}
      />
      <button onClick={handleGenerate}>Generate Design</button>
      {imageUrl && <img src={imageUrl} alt="Generated Design" />}
    </div>
  );
}

export default App;
