# AI Design Agent

This is a React-based prototype for an AI agent that generates architectural designs based on user prompts.

## Features
- Prompt input for design requests
- Display of generated images or models
- Ready for integration with GenAI backend

## Deployment
This project is configured for deployment on Vercel.

## Getting Started
1. Clone the repository
2. Run `npm install`
3. Run `npm start` to launch locally
